const Page = () => {
  return (
    <div>
      <h1>This file should not exist</h1>
      <p>Check src/App.tsx and src/components/Navbar.tsx</p>
    </div>
  )
}

export default Page
